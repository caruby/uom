module UOM
  class MeasurementError < StandardError; end
end
