# encoding: utf-8

require 'active_support/core_ext/string/inflections'

class String #:nodoc:
  include ActiveSupport::CoreExtensions::String::Inflections
end
