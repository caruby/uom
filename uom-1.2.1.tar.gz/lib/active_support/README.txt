The files in this directory are shamelessly stolen from Rails. They are included here rather than pulled in as a gem
in order to avoid a dependency on the entire Rails project for a limited utility.